This directory holds console extensions. It's only used on the admin server.
