This directory contains system modules for the security framework. It contains one security provider 
configuration extension for each of security providers in the domain's current realm.
