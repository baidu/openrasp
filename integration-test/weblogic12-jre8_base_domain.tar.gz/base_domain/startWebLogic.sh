#!/bin/sh

# WARNING: This file is created by the Configuration Wizard.
# Any changes to this script may be lost when adding extensions to this configuration.

DOMAIN_HOME="/home/oracle/domains/base_domain"

${DOMAIN_HOME}/bin/startWebLogic.sh $*

